const container = document.querySelector('#container');
const matrice   = document.querySelector('#matrice');

const onWindowResize = () => {
  let windowX = container.scrollWidth;
  let windowY = container.scrollHeight;

  if (windowX < windowY) { windowY = windowX }
  else                   { windowX = windowY }

  const matriceWidth  = windowX / 1.3;
  const matriceHeight = windowY / 1.3;

  matrice.style.top         = ((container.scrollHeight - (matriceHeight)) / 2) + 'px';
  matrice.style.left        = ((container.scrollWidth - (matriceWidth)) / 2) + 'px';
  matrice.style.width       = matriceWidth + 'px';
  matrice.style.height      = matriceHeight + 'px';
  matrice.style.perspective = matriceWidth + 'px';
}

class Dice {
  element = document.createElement('div');
  classes = ['show-front', 'show-back', 'show-right', 'show-left', 'show-top', 'show-bottom'];
  faces   = '<div class="cube__face cube__face--front"><span>1</span></div>' +
                            '<div class="cube__face cube__face--back"><span>2</span></div>' +
                            '<div class="cube__face cube__face--right"><span>3</span></div>' +
                            '<div class="cube__face cube__face--left"><span>4</span></div>' +
                            '<div class="cube__face cube__face--top"><span>5</span></div>' +
                            '<div class="cube__face cube__face--bottom"><span>6</span></div>';

  constructor() {
    this.element.classList.add('cube');
    this.element.innerHTML = this.faces;

    matrice.appendChild(this.element);
    this.element.addEventListener('click', this.run.bind(this));
  }

  run() {
    this.element.classList.add('run');
    const shuffledArray = [...this.classes].sort((a, b) => 0.5 - Math.random());
    shuffledArray.forEach((c, i) => setTimeout(() => this.goTo(c), 300 * (i + 1)));
    setTimeout(() => this.element.classList.remove('run'), 300 * 8);

    return this.classes.indexOf(shuffledArray[5]) + 1;
  }

  goTo(target) {
    this.classes.forEach((c) => this.element.classList.remove(c));
    this.element.classList.add(target);
  }
}

window.addEventListener('resize', onWindowResize)
onWindowResize();

const dice = new Dice();